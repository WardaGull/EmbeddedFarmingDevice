<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name = $_POST["name"];
	$email = $_POST["email"];
	$message = $_POST["message"];

	
	$servername = "localhost";
	$username = "your-username";
	$password = "your-password";
	$dbname = "your-database-name";
	
	?>
	
